<?php
$conn = mysqli_connect("localhost","root","","car_rental");

if(!$conn)
{
	echo "Database connection faild...";
}
?>