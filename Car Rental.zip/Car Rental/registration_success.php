<!DOCTYPE html>
<html>
<head>
    <title>Registration Successful</title>
    <script>
        window.onload = function() {
            alert("Registration successful!");
            window.location.href = "login.php"; // Redirect to login page
        };
    </script>
</head>
<body>
    
</body>
</html>